#ifndef ALIENC_H
#define ALIENC_H

#include "alien.h"
#include <raylib.h>

class alienC : public Alien
{
public:

	alienC(int edge, int type, Vector2 position, Vector2 velocity);
	void Update() override;
	void Draw() override;
	bool IsOffScreen() const override;
	Rectangle getRect() const override;
	static void LoadImages();
	static void UnloadImages();
	static Texture2D alienCImages[3];
	static Texture2D& GetImage(int edge);



};


#endif