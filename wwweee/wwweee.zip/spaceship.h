#ifndef SPACESHIP_H
#define SPACESHIP_H

#include "alien.h"
#include "laser.h"
#include <raylib.h>
#include <vector>




class Spaceship {
public:
    Spaceship();
    ~Spaceship();

    void Draw() {
        DrawTextureV(image, position, WHITE);
    }
    void MoveLeft();
    void MoveRight();
    void MoveUp();
    void MoveDown();
    void FireLaser();
    Rectangle getRect();
    void Reset();
    std::vector<Laser> lasers;
    Vector2 movementDirection;

private:
    Texture2D image;
    Vector2 position; //wektor xy w raylib
    double lastFireTime;
    Sound laserSound;
};
#endif