#ifndef LASER_H
#define LASER_H

#include "alien.h"
#include <raylib.h>
#include <vector>
#include <iostream>


class Laser {
public:
    Vector2 position;
    Vector2 velocity;
    bool active;

    Laser(Vector2 position, Vector2 velocity);
    void Update();
    void Draw();
    Rectangle getRect();
};
#endif