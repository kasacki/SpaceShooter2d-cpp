﻿#include <raylib.h>
#include <vector>
#include <string>
#include <iostream>
#include "game.h"


std::string FormatWithLeadingZeros(int number, int width) {
    std::string numberText = std::to_string(number);
    int leadingZeros = width - numberText.length();
    return numberText = std::string(leadingZeros, '0') + numberText;
}

int main()
{
    Color grey = { 29, 29, 27, 255 };
    Color blue = { 173, 216, 230, 255 };
    int offset = 50;
    int windowWidth = 750;
    int windowHeight = 700;

    InitWindow(windowWidth + offset, windowHeight + 2 * offset, "KAPITAN BOMBA");
    InitAudioDevice();

    Font font = LoadFontEx("Font/monogram.ttf", 64, 0, 0);
    Texture2D spaceshipImage = LoadTexture("Graphics/spaceship.png");

    SetTargetFPS(60);

    Game game;
    bool showMenu = true;
    while (WindowShouldClose() == false) {
        UpdateMusicStream(game.music);



        // MENU GŁÓWNE
        if (showMenu) {
            if (IsKeyPressed(KEY_ENTER)) {
                showMenu = false;
                game.run = true;
            }

            BeginDrawing();
            ClearBackground(grey);

            DrawTextEx(font, "KAPITAN BOMBA", { 160, 200 }, 50, 4, blue);
            DrawTextEx(font, "PRESS ENTER TO START", { 160, 300 }, 32, 2, blue);
            DrawTextEx(font, "USE WASD TO MOVE", { 160, 400 }, 28, 2, blue);
            DrawTextEx(font, "PRESS LMB TO SHOOT", { 160, 500 }, 28, 2, blue);
            DrawTextEx(font, "PRESS H TO SEE THE HIGHEST SCORE", { 160, 600 }, 28, 2, blue);
            if (IsKeyPressed(KEY_H)) {
                while (!IsKeyPressed(KEY_B)) {
                    UpdateMusicStream(game.music);
                    BeginDrawing();
                    ClearBackground(grey);

                    std::string highscoreText = FormatWithLeadingZeros(game.highscore, 5);
                    DrawTextEx(font, "HIGH-SCORE", { 160, 200 }, 40, 2, blue);
                    DrawTextEx(font, highscoreText.c_str(), { 160, 250 }, 40, 2, blue);
                    DrawTextEx(font, "PRESS B TO GO BACK TO MENU", { 160, 600 }, 28, 2, blue);

                    EndDrawing();
                }
                
            }
            EndDrawing();
            continue;
        }
        game.HandleInput();
        game.Update();
        BeginDrawing();
        ClearBackground(grey);
       
        DrawLineEx({ -10, 750 }, { 810, 750 }, 100, DARKBLUE);

        if (game.run and game.score<2000) {
            DrawTextEx(font, "LEVEL 01", { 570, 740 }, 34, 4, blue);
        }if
            (game.run and game.score>2000 and game.score<4000){
          
            DrawTextEx(font, "LEVEL 02", { 570, 740 }, 34, 4, blue);
            game.alienSpawnInterval = 2.5f;

        }if
            (game.run and game.score > 4000) {

            DrawTextEx(font, "LEVEL 03", { 570, 740 }, 34, 4, blue);
            game.alienSpawnInterval = 2.0f;

        }
        else if
            (game.run == false)  {
            DrawTextEx(font, "GAME OVER", { 570, 740 }, 34, 4, blue);
        }
        float x = 50.0;
        for (int i = 0; i < game.lives; i++) {
            DrawTextureV(spaceshipImage, { x, 745 }, WHITE);
            x += 50;
        }

        DrawTextEx(font, "SCORE", { 50, 15 }, 34, 2, blue);
        std::string scoreText = FormatWithLeadingZeros(game.score, 5);
        DrawTextEx(font, scoreText.c_str(), { 50, 40 }, 34, 2, blue);

        DrawTextEx(font, "HIGH-SCORE", { 570, 15 }, 34, 2, blue);
        std::string highscoreText = FormatWithLeadingZeros(game.highscore, 5);
        DrawTextEx(font, highscoreText.c_str(), { 655, 40 }, 34, 2, blue);

        game.Draw();
        EndDrawing();

        if (!game.run && !showMenu) {
            DrawTextEx(font, "PRESS R TO GO BACK TO MENU", { 160, 200 }, 32, 4, blue);
            if (IsKeyPressed(KEY_R)) {
                game.Reset();
                showMenu = true;
            }
        }
    }

    
    CloseWindow();
    CloseAudioDevice();
}