#include "alien.h"
#include <raylib.h>


Texture2D Alien::alienImages[3] = {};



Alien::Alien(int edge, int type, Vector2 position, Vector2 velocity)
    : edge(edge), type(type), position(position), velocity(velocity) {}

void Alien::Update() {}

void Alien::Draw() {}

Rectangle Alien::getRect() const {
    return { position.x, position.y,
             float(alienImages[edge - 1].width),
             float(alienImages[edge - 1].height) };
}



bool Alien::IsOffScreen() const {
    return (position.y > GetScreenHeight() - alienImages[edge - 1].height - 100 || position.x < -50 || position.x > GetScreenWidth() + 50);
}


