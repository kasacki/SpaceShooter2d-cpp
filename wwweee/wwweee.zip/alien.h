#ifndef ALIEN_H
#define ALIEN_H

#include <raylib.h>


class Alien {
public:
    Alien(int edge, int type, Vector2 position, Vector2 velocity);
    virtual void Update();
    virtual void Draw();
    virtual bool IsOffScreen() const;
    virtual Rectangle getRect() const;
    
    static Texture2D alienImages[3];
    int type;
    int edge;
    
    Vector2 position;
    Vector2 velocity;
private:
   
};

#endif
