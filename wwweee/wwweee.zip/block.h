#ifndef BLOCK_H
#define BLOCK_H

#include "alien.h"
#include <raylib.h>
#include <vector>
#include <iostream>


class Block {
public:
    Block(Vector2 position);
    void Draw();
    Rectangle getRect();
private:
    Vector2 position;
};
#endif