#ifndef MYSTERYSHIP_H
#define MYSTERYSHIP_H
#include "laser.h"
#include "alien.h"
#include <raylib.h>
#include <vector>
#include <iostream>



class MysteryShip {
public:
    MysteryShip();
    ~MysteryShip();
    void Update();
    void Draw();
    void Spawn();
    Rectangle getRect();
    bool alive;
    void FireLasers();
    float lastFireTime;
    std::vector<Laser> mlasers;
private:
    Vector2 position;
    Texture2D image;
    int speed;
};
#endif