#ifndef ALIENB_H
#define ALIENB_H

#include "alien.h"
#include <raylib.h>

class alienB : public Alien
{
public:

	alienB(int edge, int type, Vector2 position, Vector2 velocity);
	void Update() override;
	void Draw() override;
	bool IsOffScreen() const override;
	Rectangle getRect() const override;
	static void LoadImages();
	static void UnloadImages();
	static Texture2D alienBImages[3];
	static Texture2D& GetImage(int edge);

};


#endif