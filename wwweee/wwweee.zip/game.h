#ifndef GAME_H
#define GAME_H

#include "alien.h"
#include "obstacle.h"
#include "spaceship.h"
#include "mysteryship.h"
#include "laser.h"
#include "alienA.h"
#include "alienB.h"
#include "alienC.h"
#include <raylib.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <chrono>
#include <concepts>
#include <ranges>


template<typename T>
concept AlienLike = requires(T alien) {
    { alien.position } -> std::convertible_to<Vector2>;
    { alien.velocity } -> std::convertible_to<Vector2>;
    { alien.edge } -> std::convertible_to<int>;
    { T::GetImage(alien.edge) } -> std::convertible_to<Texture2D&>;
};


namespace fs = std::filesystem;



class Game {
public:
    Game();
    ~Game();
    void Draw();
    void Update();
    void HandleInput();
    bool run;
    int lives;
    int score;
    int highscore;
    double timeLastAlienFiredA = 0.0;
    double timeLastAlienFiredB = 0.0;
    double timeLastAlienFiredC = 0.0;
    Music music;
    void Reset();
    std::vector<Obstacle> CreateObstacles();
    float alienSpawnInterval;
  

private:
   
    template <AlienLike AlienType>
    void AlienShootLaserFrom(std::vector<AlienType>& aliens, double& timeLastShot, std::vector<Laser>& laserList, double interval);


    template <AlienLike AlienType>
    void HandleAlienObstacleCollision(std::vector<AlienType>& aliens);

    template<AlienLike AlienType>
    void SpawnAlien(std::vector<AlienType>& container);

    void DeleteInactiveLasers();
    void CheckForCollisions();
    void GameOver();
    void InitGame();
    void checkForHighscore();
    void saveHighscoreToFile(int highscore);
    int loadHighscoreFromFile();
    void DeleteOffScreenAliens();
    Spaceship spaceship;
    std::vector<Obstacle> obstacles;
    std::vector<alienA> aliensA;
    std::vector<alienB> aliensB;
    std::vector<alienC> aliensC;
    std::vector<Alien*> aliensToRemove;
    int currentSpawnType = 0;
    int randomType = 0;// 0 = A, 1 = B, 2 = C
    bool spawning = true;
    int aliensDirection;
    std::vector<Laser> alienLasers;
    constexpr static float alienLaserShootInterval = 0.35;
    float timeLastAlienFired;
    MysteryShip mysteryship;
    float mysteryShipSpawnInterval;
    float timeLastSpawn;
    Sound explosionSound; 
    float alienSpawnTimer;         
    
};
#endif