#include "obstacle.h"
#include <raylib.h>


std::vector<std::vector<int>> Obstacle::grid = {
    {0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0},
    {0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0},
    {0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1},
    {0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1},
    {0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0},
    {0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0}
};

Obstacle::Obstacle(Vector2 position)
{
    int gridWidth = grid[0].size() * 4;
    int gridHeight = grid.size() * 4;

    // Losowa pozycja wewn�trz ekranu
    position.x = GetRandomValue(0, GetScreenWidth() - gridWidth);
    position.y = GetRandomValue(200, GetScreenHeight() - gridHeight-100);

    for (unsigned int row = 0; row < grid.size(); ++row) {
        for (unsigned int column = 0; column < grid[0].size(); ++column) {
            if (grid[row][column] == 1) {
                float pos_x = position.x + column * 4;
                float pos_y = position.y + row * 4;
                Block block = Block({ pos_x, pos_y });
                blocks.push_back(block);
            }
        }
    }
}

void Obstacle::Draw() {
    for (auto& block : blocks) {
        block.Draw();
    }
}